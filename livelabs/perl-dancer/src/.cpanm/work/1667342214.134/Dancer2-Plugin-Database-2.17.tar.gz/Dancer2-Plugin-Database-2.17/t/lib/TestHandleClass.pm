package t::lib::TestHandleClass;
use base 'Dancer::Plugin::Database::Core::Handle';
1;
