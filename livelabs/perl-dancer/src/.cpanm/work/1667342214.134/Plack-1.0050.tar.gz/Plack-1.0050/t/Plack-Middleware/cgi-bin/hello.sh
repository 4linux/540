#!/bin/sh
echo "Content-Type: text/plain"
echo

echo "Hello foo"
echo "QUERY_STRING is $QUERY_STRING"
