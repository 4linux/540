package OnDemand::Foo;

use Moo;
use CLI::Osprey;

$OnDemand::Foo::loaded = 1;

sub run { }

1;
