package OnDemand::Bar;

use Moo;
use CLI::Osprey;

$OnDemand::Bar::loaded = 1;

sub run { }

1;
