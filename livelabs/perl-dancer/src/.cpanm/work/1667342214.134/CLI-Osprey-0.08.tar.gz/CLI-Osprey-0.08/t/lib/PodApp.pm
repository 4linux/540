package PodApp;

use Moo;

use CLI::Osprey
    description_pod => 'some description pod',
    extra_pod => 'some extra pod';

sub run {}

1;
